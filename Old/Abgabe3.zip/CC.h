#ifndef CC_H
#define CC_H

long CC_Zerlegung(long n, double *A);
void CC_VorwSubst(long n, double *A, double *b);
void CC_RueckwSubst(long n, double *A, double *b);

#endif
